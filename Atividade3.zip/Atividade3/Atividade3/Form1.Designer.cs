﻿namespace Atividade3 {
    partial class Form1 {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            lblA = new Label();
            lblC = new Label();
            lblB = new Label();
            txtA = new TextBox();
            txtB = new TextBox();
            txtC = new TextBox();
            btnCalc = new Button();
            btnLimp = new Button();
            btnSair = new Button();
            errorProvider1 = new ErrorProvider(components);
            errorProvider2 = new ErrorProvider(components);
            errorProvider3 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider3).BeginInit();
            SuspendLayout();
            // 
            // lblA
            // 
            lblA.AutoSize = true;
            lblA.BackColor = Color.Yellow;
            lblA.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblA.ForeColor = Color.Red;
            lblA.Location = new Point(94, 83);
            lblA.Name = "lblA";
            lblA.Size = new Size(108, 38);
            lblA.TabIndex = 0;
            lblA.Text = "Lado A";
            // 
            // lblC
            // 
            lblC.AutoSize = true;
            lblC.BackColor = Color.Yellow;
            lblC.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblC.ForeColor = Color.Red;
            lblC.Location = new Point(94, 264);
            lblC.Name = "lblC";
            lblC.Size = new Size(105, 38);
            lblC.TabIndex = 1;
            lblC.Text = "Lado C";
            // 
            // lblB
            // 
            lblB.AutoSize = true;
            lblB.BackColor = Color.Yellow;
            lblB.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblB.ForeColor = Color.Red;
            lblB.Location = new Point(94, 172);
            lblB.Name = "lblB";
            lblB.Size = new Size(106, 38);
            lblB.TabIndex = 2;
            lblB.Text = "Lado B";
            // 
            // txtA
            // 
            txtA.BackColor = Color.FromArgb(224, 224, 224);
            txtA.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtA.Location = new Point(270, 83);
            txtA.Name = "txtA";
            txtA.Size = new Size(235, 43);
            txtA.TabIndex = 3;
            txtA.Validated += txtA_Validated;
            // 
            // txtB
            // 
            txtB.BackColor = Color.FromArgb(224, 224, 224);
            txtB.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtB.Location = new Point(270, 172);
            txtB.Name = "txtB";
            txtB.Size = new Size(235, 43);
            txtB.TabIndex = 4;
            txtB.Validated += txtB_Validated;
            // 
            // txtC
            // 
            txtC.BackColor = Color.FromArgb(224, 224, 224);
            txtC.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtC.Location = new Point(270, 264);
            txtC.Name = "txtC";
            txtC.Size = new Size(235, 43);
            txtC.TabIndex = 5;
            txtC.Validated += txtC_Validated;
            // 
            // btnCalc
            // 
            btnCalc.BackColor = Color.FromArgb(192, 255, 192);
            btnCalc.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCalc.ForeColor = Color.Lime;
            btnCalc.Location = new Point(568, 102);
            btnCalc.Name = "btnCalc";
            btnCalc.Size = new Size(195, 68);
            btnCalc.TabIndex = 6;
            btnCalc.Text = "Calcular";
            btnCalc.UseVisualStyleBackColor = false;
            btnCalc.Click += btnCalc_Click;
            // 
            // btnLimp
            // 
            btnLimp.BackColor = Color.FromArgb(192, 255, 192);
            btnLimp.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLimp.ForeColor = Color.Lime;
            btnLimp.Location = new Point(568, 234);
            btnLimp.Name = "btnLimp";
            btnLimp.Size = new Size(195, 68);
            btnLimp.TabIndex = 7;
            btnLimp.Text = "Limpar";
            btnLimp.UseVisualStyleBackColor = false;
            btnLimp.Click += btnLimp_Click;
            // 
            // btnSair
            // 
            btnSair.BackColor = Color.FromArgb(255, 192, 192);
            btnSair.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSair.ForeColor = Color.Red;
            btnSair.Location = new Point(195, 370);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(511, 68);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = false;
            btnSair.Click += btnSair_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            errorProvider3.ContainerControl = this;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(800, 450);
            Controls.Add(btnSair);
            Controls.Add(btnLimp);
            Controls.Add(btnCalc);
            Controls.Add(txtC);
            Controls.Add(txtB);
            Controls.Add(txtA);
            Controls.Add(lblB);
            Controls.Add(lblC);
            Controls.Add(lblA);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblA;
        private Label lblC;
        private Label lblB;
        private TextBox txtA;
        private TextBox txtB;
        private TextBox txtC;
        private Button btnCalc;
        private Button btnLimp;
        private Button btnSair;
        private ErrorProvider errorProvider1;
        private ErrorProvider errorProvider2;
        private ErrorProvider errorProvider3;
    }
}
