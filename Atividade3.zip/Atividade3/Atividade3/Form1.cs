namespace Atividade3 {
    public partial class Form1 : Form {

        Double valorA, valorB, valorC;
        public Form1() {
            InitializeComponent();
        }

        private void txtA_Validated(object sender, EventArgs e) {
            try {
                errorProvider1.SetError(txtA, "");
                this.valorA = Convert.ToDouble(txtA.Text);
            }
            catch {
                errorProvider1.SetError(txtA, "Valor inválido");
                txtA.Focus();
                txtA.SelectAll();
            }
        }

        private void txtB_Validated(object sender, EventArgs e) {
            try {
                errorProvider2.SetError(txtB, "");
                this.valorB = Convert.ToDouble(txtB.Text);
            }
            catch {
                errorProvider2.SetError(txtB, "Valor inválido");
                txtB.Focus();
                txtB.SelectAll();
            }
        }

        private void txtC_Validated(object sender, EventArgs e) {
            try {
                errorProvider3.SetError(txtC, "");
                this.valorC = Convert.ToDouble(txtC.Text);
            }
            catch {
                errorProvider3.SetError(txtC, "Valor inválido");
                txtC.Focus();
                txtC.SelectAll();
            }
        }

        private void btnCalc_Click(object sender, EventArgs e) {                       
            
            if (valorA < (valorB + valorC) && valorB < (valorA + valorC) && valorC < (valorA + valorB)) {
                if (valorA == valorB && valorA == valorC) {
                    MessageBox.Show("Triângulo Equilátero");
                }
                else if (valorA == valorB || valorA == valorC || valorB == valorC) {
                    MessageBox.Show("Triângulo Isósceles");
                }
                else {
                    MessageBox.Show("Triângulo Escaleno");
                }
            }
            else {
                MessageBox.Show("Não é um triângulo");
            }
        }

        private void btnLimp_Click(object sender, EventArgs e) {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();

            valorA = 0;
            valorB = 0;
            valorC = 0;

            errorProvider1.SetError(txtA, "");
            errorProvider2.SetError(txtB, "");
            errorProvider3.SetError(txtC, "");

            txtA.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e) {
            Close();
        }
    }
}
