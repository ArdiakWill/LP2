﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade8
{
    public partial class frmExercicio5 : Form
    {
        private const int N = 5;

        private string[] gabarito = { "A", "B", "C", "D", "A", "B", "C", "D", "A", "B" };

        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[,] matrizRespostas = new string[N, 10];

            lstResultados.Items.Clear();

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    string respostaDigitada = "";
                    bool respostaValida = false;

                    while (!respostaValida)
                    {
                       respostaDigitada = Interaction.InputBox($"Aluno {i + 1}\nDigite a resposta da questão {j + 1} (A, B, C, D ou E):", "Entrada de Respostas");

                        respostaDigitada = respostaDigitada.ToUpper().Trim();

                        if (respostaDigitada == "A" || respostaDigitada == "B" ||
                            respostaDigitada == "C" || respostaDigitada == "D" ||
                            respostaDigitada == "E")
                        {
                            respostaValida = true;
                        }
                        else
                        {
                            MessageBox.Show("Resposta inválida! Digite apenas A, B, C, D ou E (Maiúsculas).", "Erro");
                        }
                    }

                  
                    matrizRespostas[i, j] = respostaDigitada;
                }
            } 

            for (int i = 0; i < N; i++)
            {
                int totalAcertos = 0;

                for (int j = 0; j < 10; j++)
                {
                    string escolha = matrizRespostas[i, j];
                    string correta = gabarito[j];

                    if (escolha == correta)
                    {
                       lstResultados.Items.Add($"aluno:{i + 1} acertou questão:{j + 1} era {correta} escolheu {escolha}");
                        totalAcertos++;
                    }
                    else
                    {
                        lstResultados.Items.Add($"aluno:{i + 1} errou questão:{j + 1} era {correta} escolheu {escolha}");
                    }
                }

              
                lstResultados.Items.Add($">>> Aluno {i + 1} totalizou {totalAcertos} acerto(s).");
                lstResultados.Items.Add("-------------------------------------------------------------------------");
            }
        }
    }
}
