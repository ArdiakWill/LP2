﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace Atividade8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];

            string aux = "";

            for(int i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o {i + 1} n°", "Entrada de Dados");

                if(!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Numero invalido!");
                    i--;
                }
            }

            Array.Reverse(vetor);
            aux = "";

            foreach (int x in vetor)            
                aux += x +" | ";
                MessageBox.Show(aux);     
         }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList listaAlunos = new ArrayList()
            {"Ana","André", "Beatriz", "Camila", "João", "Joana",
             "Otávio","Marcelo","Pedro", "Thais"};
            listaAlunos.Remove("Otávio");
            string aux = "";
            foreach (string nome in listaAlunos)
            {
                aux += nome +" | ";  
            }
            MessageBox.Show(aux);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];

            string aux = "";
            string saida = "";

            for (int i = 0; i < 20; i++)
            {
                double somarNotas = 0;
                for (int j = 0; j < 3; j++)
                {
                    aux = Interaction.InputBox($"Aluno {i+1} nota {j+1}");
                    if(aux == "")
                    {
                        return;
                    }
                    if (!double.TryParse(aux, out notas[i,j]) && notas[i, j] >= 0 && notas[i, j] <= 10)
                    {
                        MessageBox.Show("Nota invalida!");
                        j--;
                        
                    }
                    else
                    {
                        somarNotas += notas[i, j];
                    }                   
                }
                double media = somarNotas / 3;
                saida+=$"Aluno {i+1} Media final {media:N2} \n";
            }

            MessageBox.Show(saida);
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                MessageBox.Show("Form ja existe!");
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 frm4 = new frmExercicio4();
                frm4.Show();
            }
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 frm5 = new frmExercicio5();
                frm5.Show();
            }
        }
    }
}
