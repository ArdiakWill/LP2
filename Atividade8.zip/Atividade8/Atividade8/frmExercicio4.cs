﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade8
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] vetorNomes = new string[10];
            int[] vetorTamanhos = new int[10];

            lstResultados.Items.Clear();

            for (int i = 0; i < 10; i++)
            {
                string nomeDigitado = "";
                bool entradaValida = false;

                               

                while (!entradaValida)
                {
                    nomeDigitado = Interaction.InputBox($"Digite o {i + 1}º nome completo:", "Entrada de Dados - Exercício 4");

                    if (string.IsNullOrWhiteSpace(nomeDigitado))
                    {
                        MessageBox.Show("Atenção: Não é permitido nome vazio! Por favor, digite um nome válido.", "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        entradaValida = true;
                    }

                }

                vetorNomes[i] = nomeDigitado.Trim();

                string nomeSemEspacos = nomeDigitado.Replace(" ", "");

                vetorTamanhos[i] = nomeSemEspacos.Length;
            }

            for (int i = 0; i < 10; i++)
            {
                lstResultados.Items.Add($"Nome: {vetorNomes[i]} -> Tamanho: {vetorTamanhos[i]} caracteres");
            }
        }

    }
}
