﻿namespace Atividade1 {
    partial class Form1 {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            lblNumero1 = new Label();
            lblNumero2 = new Label();
            lblResultado = new Label();
            txtNumero1 = new TextBox();
            txtNumero2 = new TextBox();
            txtResultado = new TextBox();
            btnLimpar = new Button();
            BtnSair = new Button();
            BtnSomar = new Button();
            btnSubtrair = new Button();
            btnMultiplicar = new Button();
            btnDividir = new Button();
            SuspendLayout();
            // 
            // lblNumero1
            // 
            lblNumero1.AutoSize = true;
            lblNumero1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNumero1.Location = new Point(82, 44);
            lblNumero1.Name = "lblNumero1";
            lblNumero1.Size = new Size(121, 31);
            lblNumero1.TabIndex = 0;
            lblNumero1.Text = "Numero 1";
            // 
            // lblNumero2
            // 
            lblNumero2.AutoSize = true;
            lblNumero2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNumero2.Location = new Point(82, 130);
            lblNumero2.Name = "lblNumero2";
            lblNumero2.Size = new Size(121, 31);
            lblNumero2.TabIndex = 1;
            lblNumero2.Text = "Numero 2";
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblResultado.Location = new Point(82, 216);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(120, 31);
            lblResultado.TabIndex = 2;
            lblResultado.Text = "Resultado";
            // 
            // txtNumero1
            // 
            txtNumero1.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtNumero1.Location = new Point(262, 41);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(239, 38);
            txtNumero1.TabIndex = 3;
            txtNumero1.Validated += txtNumero1_Validated;
            // 
            // txtNumero2
            // 
            txtNumero2.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtNumero2.Location = new Point(262, 127);
            txtNumero2.Name = "txtNumero2";
            txtNumero2.Size = new Size(239, 38);
            txtNumero2.TabIndex = 4;
            txtNumero2.Validated += txtNumero2_Validated;
            // 
            // txtResultado
            // 
            txtResultado.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtResultado.Location = new Point(262, 213);
            txtResultado.Name = "txtResultado";
            txtResultado.Size = new Size(239, 38);
            txtResultado.TabIndex = 5;
            txtResultado.TextChanged += txtResultado_TextChanged;
            // 
            // btnLimpar
            // 
            btnLimpar.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLimpar.ForeColor = Color.Blue;
            btnLimpar.Location = new Point(570, 98);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(184, 52);
            btnLimpar.TabIndex = 6;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // BtnSair
            // 
            BtnSair.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BtnSair.ForeColor = Color.Red;
            BtnSair.Location = new Point(570, 174);
            BtnSair.Name = "BtnSair";
            BtnSair.Size = new Size(184, 52);
            BtnSair.TabIndex = 7;
            BtnSair.Text = "Sair";
            BtnSair.UseVisualStyleBackColor = true;
            BtnSair.Click += BtnSair_Click;
            // 
            // BtnSomar
            // 
            BtnSomar.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BtnSomar.Location = new Point(82, 320);
            BtnSomar.Name = "BtnSomar";
            BtnSomar.Size = new Size(125, 77);
            BtnSomar.TabIndex = 8;
            BtnSomar.Text = "+";
            BtnSomar.UseVisualStyleBackColor = true;
            BtnSomar.Click += BtnSomar_Click;
            // 
            // btnSubtrair
            // 
            btnSubtrair.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSubtrair.Location = new Point(262, 320);
            btnSubtrair.Name = "btnSubtrair";
            btnSubtrair.Size = new Size(125, 77);
            btnSubtrair.TabIndex = 9;
            btnSubtrair.Text = "-";
            btnSubtrair.UseVisualStyleBackColor = true;
            btnSubtrair.Click += btnSubtrair_Click;
            // 
            // btnMultiplicar
            // 
            btnMultiplicar.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMultiplicar.Location = new Point(433, 320);
            btnMultiplicar.Name = "btnMultiplicar";
            btnMultiplicar.Size = new Size(125, 77);
            btnMultiplicar.TabIndex = 10;
            btnMultiplicar.Text = "*";
            btnMultiplicar.UseVisualStyleBackColor = true;
            btnMultiplicar.Click += btnMultiplicar_Click;
            // 
            // btnDividir
            // 
            btnDividir.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDividir.Location = new Point(610, 320);
            btnDividir.Name = "btnDividir";
            btnDividir.Size = new Size(125, 77);
            btnDividir.TabIndex = 11;
            btnDividir.Text = "/";
            btnDividir.UseVisualStyleBackColor = true;
            btnDividir.Click += btnDividir_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnDividir);
            Controls.Add(btnMultiplicar);
            Controls.Add(btnSubtrair);
            Controls.Add(BtnSomar);
            Controls.Add(BtnSair);
            Controls.Add(btnLimpar);
            Controls.Add(txtResultado);
            Controls.Add(txtNumero2);
            Controls.Add(txtNumero1);
            Controls.Add(lblResultado);
            Controls.Add(lblNumero2);
            Controls.Add(lblNumero1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNumero1;
        private Label lblNumero2;
        private Label lblResultado;
        private TextBox txtNumero1;
        private TextBox txtNumero2;
        private TextBox txtResultado;
        private Button btnLimpar;
        private Button BtnSair;
        private Button BtnSomar;
        private Button btnSubtrair;
        private Button btnMultiplicar;
        private Button btnDividir;
    }
}
