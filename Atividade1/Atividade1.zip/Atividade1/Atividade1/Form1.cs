namespace Atividade1 {
    public partial class Form1 : Form {

        double numero1, numero2;
        string resultado = "";

        public Form1() {
            InitializeComponent();
        }

        private void txtNumero1_Validated(object sender, EventArgs e) {
            if (!double.TryParse(txtNumero1.Text, out numero1)) {
                MessageBox.Show("Apenas Números");
                txtNumero1.Clear();
                txtNumero1.Focus();
            }
        }
        private void txtNumero2_Validated(object sender, EventArgs e) {
            if (this.ActiveControl == BtnSair) {
                return;
            }
            if (!double.TryParse(txtNumero2.Text, out numero2)) {
                MessageBox.Show("Apenas Números");
                txtNumero2.Clear();
                txtNumero2.Focus();

            }
        }

        private void btnLimpar_Click(object sender, EventArgs e) {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();

            numero1 = 0;
            numero2 = 0;
            resultado = "";

            txtResultado.Focus();
        }

        private void BtnSair_Click(object sender, EventArgs e) {
           this.Close();
        }

        private void BtnSomar_Click(object sender, EventArgs e) {
            resultado = (numero1 + numero2).ToString();
            txtResultado.Text = resultado;
        }

        private void btnSubtrair_Click(object sender, EventArgs e) {
            resultado = (numero1 - numero2).ToString();
            txtResultado.Text = resultado;
        }

        private void btnMultiplicar_Click(object sender, EventArgs e) {
            resultado = (numero1 * numero2).ToString();
            txtResultado.Text = resultado;
        }

        private void btnDividir_Click(object sender, EventArgs e) {
            if (numero2 == 0) {
                MessageBox.Show("Não é possível dividir por zero.");
                txtNumero2.Clear();
                txtNumero2.Focus();
            }
            else {
                resultado = (numero1 / numero2).ToString();
                txtResultado.Text = resultado;
            }
        }

        private void txtResultado_TextChanged(object sender, EventArgs e) {
            txtResultado.Text = resultado;
        }
    }
}
