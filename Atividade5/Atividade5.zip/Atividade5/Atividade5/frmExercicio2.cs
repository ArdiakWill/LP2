﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcularH_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtN.Text, out int n) && n > 0) 
            {
                double h = 0;
                for (int i = 1; i <= n; i++) 
                {
                    h += 1.0 / i;
                }

                MessageBox.Show($"O valor de H e: {h.ToString("F4")}");
            }
            else
            {
                MessageBox.Show("Digite um valor para N que seja maior que 0");
            }

        }
    }
}
