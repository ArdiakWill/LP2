﻿namespace Atividade5
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtbFrase = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnEspacos = new System.Windows.Forms.Button();
            this.btnLetrasR = new System.Windows.Forms.Button();
            this.btnPares = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtbFrase
            // 
            this.rtbFrase.BackColor = System.Drawing.SystemColors.Info;
            this.rtbFrase.ForeColor = System.Drawing.SystemColors.WindowText;
            this.rtbFrase.Location = new System.Drawing.Point(181, 51);
            this.rtbFrase.Name = "rtbFrase";
            this.rtbFrase.Size = new System.Drawing.Size(395, 50);
            this.rtbFrase.TabIndex = 0;
            this.rtbFrase.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(98, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Frase";
            // 
            // btnEspacos
            // 
            this.btnEspacos.Location = new System.Drawing.Point(101, 273);
            this.btnEspacos.Name = "btnEspacos";
            this.btnEspacos.Size = new System.Drawing.Size(122, 59);
            this.btnEspacos.TabIndex = 2;
            this.btnEspacos.Text = "Qunatidade de Espacos em Branco";
            this.btnEspacos.UseVisualStyleBackColor = true;
            this.btnEspacos.Click += new System.EventHandler(this.btnEspacos_Click);
            // 
            // btnLetrasR
            // 
            this.btnLetrasR.Location = new System.Drawing.Point(304, 273);
            this.btnLetrasR.Name = "btnLetrasR";
            this.btnLetrasR.Size = new System.Drawing.Size(122, 59);
            this.btnLetrasR.TabIndex = 3;
            this.btnLetrasR.Text = "Quantidade de Letras R";
            this.btnLetrasR.UseVisualStyleBackColor = true;
            this.btnLetrasR.Click += new System.EventHandler(this.btnLetrasR_Click);
            // 
            // btnPares
            // 
            this.btnPares.Location = new System.Drawing.Point(508, 273);
            this.btnPares.Name = "btnPares";
            this.btnPares.Size = new System.Drawing.Size(122, 59);
            this.btnPares.TabIndex = 4;
            this.btnPares.Text = "Quantidade de Pares de Letras";
            this.btnPares.UseVisualStyleBackColor = true;
            this.btnPares.Click += new System.EventHandler(this.btnPares_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnPares);
            this.Controls.Add(this.btnLetrasR);
            this.Controls.Add(this.btnEspacos);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rtbFrase);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtbFrase;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnEspacos;
        private System.Windows.Forms.Button btnLetrasR;
        private System.Windows.Forms.Button btnPares;
    }
}