﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcularSalario_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text;
            string matricula = txtMatricula.Text;
            int producao = int.Parse(txtProducao.Text);
            double salarioA = double.Parse(txtSalario.Text);
            double gratificacao = double.Parse(txtGratificacao.Text);
            int B = producao >= 100 ? 1 : 0;
            int C = producao >= 120 ? 1 : 0;
            int D = producao >= 150 ? 1 : 0;

            double salarioBruto = salarioA + salarioA * (0.05 * B + 0.10 * C + 0.10 * D) + gratificacao;

            if (salarioBruto > 7000.00)
            {
                bool bonus = (producao >= 150 && gratificacao > 0);
                if (!bonus)
                {
                    salarioBruto = 7000.00;
                }
            }
            MessageBox.Show($"Funcionário: {nome}\nMatricula: {matricula}\nSalário bruto: {salarioBruto:C2}");
        }
    }
}
