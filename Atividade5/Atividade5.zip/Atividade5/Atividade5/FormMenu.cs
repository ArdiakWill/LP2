﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class FormMenu : Form
    {
        public FormMenu()
        {
            InitializeComponent();
        }

        private void exercicio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio1 ex1 = new frmExercicio1();
            ex1.Show();
        }

        private void exercicio2ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            frmExercicio2 ex2 = new frmExercicio2();
            ex2.Show();
        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio3 ex3 = new frmExercicio3();
            ex3.Show();
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio4 ex4 = new frmExercicio4();
            ex4.Show();
        }
    }
}
