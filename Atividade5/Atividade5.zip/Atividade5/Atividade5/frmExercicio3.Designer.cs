﻿namespace Atividade5
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtFrase = new System.Windows.Forms.TextBox();
            this.btnVerificarPalindromo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(143, 103);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Digite:";
            // 
            // txtFrase
            // 
            this.txtFrase.Location = new System.Drawing.Point(229, 100);
            this.txtFrase.Name = "txtFrase";
            this.txtFrase.Size = new System.Drawing.Size(300, 22);
            this.txtFrase.TabIndex = 1;
            // 
            // btnVerificarPalindromo
            // 
            this.btnVerificarPalindromo.Location = new System.Drawing.Point(275, 189);
            this.btnVerificarPalindromo.Name = "btnVerificarPalindromo";
            this.btnVerificarPalindromo.Size = new System.Drawing.Size(179, 60);
            this.btnVerificarPalindromo.TabIndex = 2;
            this.btnVerificarPalindromo.Text = "Verificar Palíndromo";
            this.btnVerificarPalindromo.UseVisualStyleBackColor = true;
            this.btnVerificarPalindromo.Click += new System.EventHandler(this.btnVerificarPalindromo_Click);
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnVerificarPalindromo);
            this.Controls.Add(this.txtFrase);
            this.Controls.Add(this.label1);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFrase;
        private System.Windows.Forms.Button btnVerificarPalindromo;
    }
}