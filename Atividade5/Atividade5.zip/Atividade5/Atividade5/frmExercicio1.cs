﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacos_Click(object sender, EventArgs e)
        {
            string frase = rtbFrase.Text;
            int espacos = 0;
            int i = 0;
            while (i < frase.Length)
            {
                if (frase[i] == ' ')
                    espacos++;
                i++;
            }
            MessageBox.Show($"Numero de espacos em branco: {espacos}");
        }

        private void btnLetrasR_Click(object sender, EventArgs e)
        {
            int contR = 0;
            foreach (char letra in rtbFrase.Text.ToUpper())
            {
                if (letra == 'R')
                    contR++;
            }
            MessageBox.Show($"Numero de letras R: {contR}");
        }

        private void btnPares_Click(object sender, EventArgs e)
        {
            string frase = rtbFrase.Text.ToLower();
            int pares = 0;
            for (int i = 0; i < frase.Length -1; i++)
            {
                if (char.IsLetter(frase[i]) && frase[i] == frase[i + 1])
                {
                    pares++;
                }
            }
            MessageBox.Show($"Numero de pares de letras: {pares}");
        }
    }
}
