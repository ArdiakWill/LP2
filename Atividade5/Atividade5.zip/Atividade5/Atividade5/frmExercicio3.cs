﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnVerificarPalindromo_Click(object sender, EventArgs e)
        {
            string entrada = txtFrase.Text;

            if (entrada.Length > 50)
            {
                MessageBox.Show("A frase nao deve ter mais do que 50 caracteres");
                return;
            }

            string fraseLimpa = entrada.Replace(" ", "").ToUpper();

            char[] arrayFrase = fraseLimpa.ToCharArray();
            Array.Reverse(arrayFrase);
            string fraseInvertida = new string(arrayFrase);

            
            if (fraseLimpa == fraseInvertida)
            {
                MessageBox.Show("É um Palíndromo!");
            }
            else
            {
                MessageBox.Show("Nao é um Palíndromo!");
            }
        }
    }
}
